package com.example.my18plusapp

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class SecondActivity : AppCompatActivity(), SeekBar.OnSeekBarChangeListener {

    private lateinit var redBar: SeekBar
    private lateinit var greenBar: SeekBar
    private lateinit var blueBar: SeekBar
    private lateinit var colorView: TextView
    private lateinit var switchBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main2)  // Make sure this layout file exists!

//        switchBtn = findViewById(R.id.switchBtn)
//        switchBtn.setOnClickListener {
//            // You can switch back to MainActivity or any other activity if you want
//            val intent = Intent(this, MainActivity::class.java)
//            startActivity(intent)
//            finish()
//        }

        redBar = findViewById(R.id.seekBarRed)
        greenBar = findViewById(R.id.seekBarGreen)
        blueBar = findViewById(R.id.seekBarBlue)
        colorView = findViewById(R.id.textView4)

        redBar.setOnSeekBarChangeListener(this)
        greenBar.setOnSeekBarChangeListener(this)
        blueBar.setOnSeekBarChangeListener(this)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
        val redColor = redBar.progress
        val greenColor = greenBar.progress
        val blueColor = blueBar.progress

        // Update colorView background and text
        colorView.setBackgroundColor(Color.rgb(redColor, greenColor, blueColor))

        val colorValue = String.format("#%02X%02X%02X", redColor, greenColor, blueColor)
        colorView.text = colorValue

        // Invert color for text for visibility
        colorView.setTextColor(Color.rgb(255 - redColor, 255 - greenColor, 255 - blueColor))

        // Make TextView visible on first color change
        if (colorView.visibility != View.VISIBLE) {
            colorView.visibility = View.VISIBLE
        }
    }


    override fun onStartTrackingTouch(seekBar: SeekBar?) {
        // No-op
    }

    override fun onStopTrackingTouch(seekBar: SeekBar?) {
        // No-op
    }
}
