package com.example.my18plusapp

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var button: Button       // PLAY button (id: button)
    private lateinit var nextButton: Button   // NEXT button (id: button2)
    private var mediaPlayer: MediaPlayer? = null
    private lateinit var audioManager: AudioManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Play button setup
        button = findViewById(R.id.button)
        button.setOnClickListener {
            playAudio()
        }

        // Next button setup
        nextButton = findViewById(R.id.button2)
        nextButton.setOnClickListener {
            val intent = Intent(this, SecondActivity::class.java)
            startActivity(intent)
        }
    }

    private fun playAudio() {
        // Stop and release existing media player immediately
        mediaPlayer?.let {
            if (it.isPlaying) {
                it.stop()
            }
            it.release()
        }

        mediaPlayer = MediaPlayer()

        // Adjust volume if you want
        val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val newVolume = (currentVolume + 1).coerceAtMost(maxVolume)
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, newVolume, 0)

        try {
            val audioUri = Uri.parse("android.resource://${packageName}/raw/oofed")
            mediaPlayer?.setDataSource(this, audioUri)

            // Use prepare() instead of prepareAsync() for immediate preparation
            mediaPlayer?.prepare()

            mediaPlayer?.setVolume(1.0f, 1.0f)
            mediaPlayer?.start()

            Toast.makeText(this, "Audio started playing", Toast.LENGTH_SHORT).show()

            mediaPlayer?.setOnCompletionListener {
                // Optional: do something when audio finishes
            }

            mediaPlayer?.setOnErrorListener { mp, what, extra ->
                Toast.makeText(this, "Error playing audio", Toast.LENGTH_SHORT).show()
                mp.release()
                mediaPlayer = null
                true
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to play audio: ${e.message}", Toast.LENGTH_SHORT).show()
            mediaPlayer?.release()
            mediaPlayer = null
        }
    }



    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer?.release()
        mediaPlayer = null
    }
}
