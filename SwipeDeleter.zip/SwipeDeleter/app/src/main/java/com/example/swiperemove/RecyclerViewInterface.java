package com.example.swiperemove;

public interface RecyclerViewInterface {
    void onItemClick(int position);
}
