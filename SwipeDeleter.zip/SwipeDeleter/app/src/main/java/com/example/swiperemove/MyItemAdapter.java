package com.example.swiperemove;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyItemAdapter extends RecyclerView.Adapter<MyItemHolder> {
    Context context;
    LayoutInflater inflater;
    ArrayList<String> list;

    public MyItemAdapter(Context context, ArrayList<String> list) {
        this.context = context;
        this.list = list;
        this.inflater=LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public MyItemHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyItemHolder(inflater.inflate(R.layout.item_layout,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyItemHolder holder, int position) {
        holder.textView.setText(list.get(position).toUpperCase());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}
